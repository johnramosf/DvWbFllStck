require("dotenv").config();


module.exports={
    app:{
        port:process.env.PORT , /* si no encuentra un puerto designado por default use el 4000 */
    }
}